%% Ploteo comparativo BER vs SNR para varios archivos DDBDM
% Carga archivos que contienen: SNRvec, berCom_vs_SNR, berNav_vs_SNR, berSum_vs_SNR
% Si el archivo es .mat -> load; si es .m (script) -> run.
clear; close all; clc;

% Lista de archivos (ajusta nombres si difieren exactamente)
files = { ...
    'BER_sweep_results_DDBDM_CNPR_20dB.m', ...
    'BER_sweep_results_DDBDM_CNPR_10dB.m', ...
    'BER_sweep_results_DDBDM_CNPR_0dB.m' ...
};

nFiles = numel(files);

% Estructuras para almacenar datos cargados
data = struct('label',{}, 'SNRvec',{}, 'berCom',{}, 'berNav',{}, 'berSum',{});

for k = 1:nFiles
    fname = files{k};
    fprintf('Procesando archivo: %s\n', fname);
    % Intentar cargar .mat si existe
    [~, nameOnly, ext] = fileparts(fname);
    loaded = false;
    try
        % Si existe un .mat con mismo nombre, úsalo
        matname = [nameOnly '.mat'];
        if exist(matname, 'file')
            tmp = load(matname);
            loaded = true;
            fprintf('  -> cargado %s (MAT-file)\n', matname);
        else
            % si fname es .m y existe como archivo, intentar ejecutarlo
            if exist(fname, 'file') == 2
                % ejecutar script: se asume que crea las variables nombradas
                run(fname);
                % capturar variables del workspace: SNRvec, berCom_vs_SNR, berNav_vs_SNR, berSum_vs_SNR
                tmp.SNRvec = evalin('base','SNRvec');
                tmp.berCom_vs_SNR = evalin('base','berCom_vs_SNR');
                tmp.berNav_vs_SNR = evalin('base','berNav_vs_SNR');
                tmp.berSum_vs_SNR = evalin('base','berSum_vs_SNR');
                loaded = true;
                fprintf('  -> ejecutado script %s\n', fname);
            else
                error('Archivo no encontrado: %s', fname);
            end
        end
    catch ME
        warning('No se pudo cargar %s: %s', fname, ME.message);
        loaded = false;
    end

    if ~loaded
        continue;
    end

    % Normalizar nombres de las variables posibles
    % Preferimos SNRvec, berCom_vs_SNR, berNav_vs_SNR, berSum_vs_SNR
    if ~isfield(tmp,'SNRvec') && isfield(tmp,'SNR')
        tmp.SNRvec = tmp.SNR;
    end
    % buscar variaciones de nombres por si los archivos guardaron otras variables
    if ~isfield(tmp,'berCom_vs_SNR') && isfield(tmp,'berCom')
        tmp.berCom_vs_SNR = tmp.berCom;
    end
    if ~isfield(tmp,'berNav_vs_SNR') && isfield(tmp,'berNav')
        tmp.berNav_vs_SNR = tmp.berNav;
    end
    if ~isfield(tmp,'berSum_vs_SNR') && isfield(tmp,'berSum')
        tmp.berSum_vs_SNR = tmp.berSum;
    end

    % Verificar existencia de variables críticas
    if ~isfield(tmp,'SNRvec') || ~isfield(tmp,'berCom_vs_SNR') || ~isfield(tmp,'berNav_vs_SNR')
        warning('Archivo %s no contiene las variables esperadas. Se omite.', fname);
        continue;
    end

    % Preparar etiqueta a partir del nombre (extraer CNPR_*dB si está)
    % Buscamos patrón 'CNPR_<valor>dB' en el nombre del archivo
    label = nameOnly;
    tok = regexp(nameOnly, 'CNPR_(-?\d+)dB', 'tokens', 'once');
    if ~isempty(tok)
        label = ['CNPR ' tok{1} ' dB'];
    end

    % Guardar en estructura
    data(end+1).label = label; %#ok<SAGROW>
    data(end).SNRvec = tmp.SNRvec(:)';
    data(end).berCom  = tmp.berCom_vs_SNR(:)';
    data(end).berNav  = tmp.berNav_vs_SNR(:)';
    if isfield(tmp,'berSum_vs_SNR')
        data(end).berSum = tmp.berSum_vs_SNR(:)';
    else
        data(end).berSum = data(end).berCom + data(end).berNav;
    end
end

% Verificación: al menos un dataset cargado
if isempty(data)
    error('No se cargó ningún dataset válido. Verifica nombres y variables en los archivos.');
end

mode = 'nan';   % cambia a 'cut' si prefieres eliminar las entradas

for k = 1:numel(data)
    % Asegurar vectores fila
    SNRv = data(k).SNRvec(:).';
    berC = data(k).berCom(:).';
    berN = data(k).berNav(:).';
    berS = data(k).berSum(:).';
    L = numel(SNRv);

    % Función auxiliar inline: índice último > 0 (ignorando NaN)
    lastPosIdx = @(x) find(~isnan(x) & (x>0), 1, 'last');

    % comunicaciones
    lastC = lastPosIdx(berC);
    if isempty(lastC)
        % no hay valores positivos -> todo NaN o empty (según mode)
        if strcmp(mode,'nan')
            berC(:) = NaN;
        else % cut
            SNRv = []; berC = [];
        end
    else
        if strcmp(mode,'nan')
            % reemplazar todo 0 después de lastC por NaN
            zeroTail = ( (1:L) > lastC ) & (berC == 0);
            berC(zeroTail) = NaN;
        else % cut
            SNRv = SNRv(1:lastC);
            berC = berC(1:lastC);
        end
    end

    % navegación
    lastN = lastPosIdx(berN);
    if isempty(lastN)
        if strcmp(mode,'nan')
            berN(:) = NaN;
        else
            SNRv = []; berN = [];
        end
    else
        if strcmp(mode,'nan')
            zeroTail = ( (1:L) > lastN ) & (berN == 0);
            berN(zeroTail) = NaN;
        else
            SNRv = SNRv(1:lastN);
            berN = berN(1:lastN);
        end
    end

    % suma
    lastS = lastPosIdx(berS);
    if isempty(lastS)
        if strcmp(mode,'nan')
            berS(:) = NaN;
        else
            SNRv = []; berS = [];
        end
    else
        if strcmp(mode,'nan')
            zeroTail = ( (1:L) > lastS ) & (berS == 0);
            berS(zeroTail) = NaN;
        else
            SNRv = SNRv(1:lastS);
            berS = berS(1:lastS);
        end
    end

    % Guardar cambios en estructura. 
    % Si se seleccionó 'cut' es posible que SNRv haya sido acortado diferentemente para cada métrica.
    % Para evitar inconsistencias, si usas 'cut' guardamos la versión más corta encontrada entre las tres métricas.
    if strcmp(mode,'cut')
        % truncar todo al mínimo largo común entre SNRv, berC, berN, berS
        lens = [numel(SNRv), numel(berC), numel(berN), numel(berS)];
        minL = min(lens);
        if minL == 0
            % dataset queda vacío: marcar variables vacías
            data(k).SNRvec = [];
            data(k).berCom = [];
            data(k).berNav = [];
            data(k).berSum = [];
            continue;
        end
        data(k).SNRvec = SNRv(1:minL);
        data(k).berCom = berC(1:minL);
        data(k).berNav = berN(1:minL);
        data(k).berSum = berS(1:minL);
    else
        % modo 'nan' conserva SNRvec original
        data(k).SNRvec = data(k).SNRvec; % sin cambio en SNRvec
        data(k).berCom = berC;
        data(k).berNav = berN;
        data(k).berSum = berS;
    end
end

% Eliminar datasets vacíos (posible tras 'cut')
keepIdx = true(1,numel(data));
for k = 1:numel(data)
    if isempty(data(k).SNRvec) || isempty(data(k).berCom)
        warning('Dataset %s quedó vacío tras limpieza y será ignorado.', data(k).label);
        keepIdx(k) = false;
    end
end
data = data(keepIdx);

% Recalcular SNR_min y SNR_max a partir de los SNRvec válidos restantes
allSNR = [data.SNRvec];
if isempty(allSNR)
    error('Tras limpiar los ceros no quedan SNR válidos en ningún dataset.');
end
SNR_min = min(allSNR);
SNR_max = max(allSNR);

% Crear SNRfine (eje fino) con nuevo rango
SNRfine = linspace(SNR_min, SNR_max, 400);

% Función auxiliar: generar curva suave usando fit()
interpBER = @(SNRin, BERin, SNRfine) smoothBERfit(SNRin, BERin, SNRfine);

% Colores y marcadores
cols = lines(numel(data));
markers = {'o','s','^','d','v','p','h'};

%% ===== 1) Figura Comunicaciones =====
figure('Name','BER Comunicaciones - comparativo'); hold on; grid on;
for k = 1:numel(data)
    SNRv = data(k).SNRvec;
    berv  = data(k).berCom;
    % Evitar ceros (log indefinido) -> reemplazar ceros por min_nonzero/10
    minpos = min(berv(berv>0));
    if isempty(minpos), minpos = 1e-6; end
    berv_safe = berv;
    berv_safe(berv_safe==0) = minpos/10;
    % Puntos originales
    plot(SNRv, berv, ['-' markers{mod(k-1,numel(markers))+1}], 'Color', cols(k,:), ...
        'LineWidth', 1, 'MarkerSize',6, 'DisplayName', data(k).label);
    % Curva suave usando fit()
    smoothBer = interpBER(SNRv, berv_safe, SNRfine);
    semilogy(SNRfine, smoothBer, 'Color', cols(k,:), 'LineWidth', 1.6);
end
set(gca,'YScale','log');
xlabel('SNR (dB)'); ylabel('BER'); title('BER vs SNR - Comunicaciones (QPSK)');
xlim([SNR_min SNR_max]); ylim([1e-6 1]);
legend('Location','southwest'); hold off;

%% ===== 2) Figura Navegación =====
figure('Name','BER Navegación - comparativo'); hold on; grid on;
for k = 1:numel(data)
    SNRv = data(k).SNRvec;
    berv  = data(k).berNav;
    minpos = min(berv(berv>0));
    if isempty(minpos), minpos = 1e-6; end
    berv_safe = berv;
    berv_safe(berv_safe==0) = minpos/10;
    plot(SNRv, berv, ['-' markers{mod(k-1,numel(markers))+1}], 'Color', cols(k,:), ...
        'LineWidth', 1, 'MarkerSize',6, 'DisplayName', data(k).label);
    smoothBer = interpBER(SNRv, berv_safe, SNRfine);
    semilogy(SNRfine, smoothBer, 'Color', cols(k,:), 'LineWidth', 1.6);
end
set(gca,'YScale','log');
xlabel('SNR (dB)'); ylabel('BER'); title('BER vs SNR - Navegación (BPSK)');
xlim([SNR_min SNR_max]); ylim([1e-6 1]);
legend('Location','southwest'); hold off;

%% ===== 3) Figura Suma (Com + Nav) =====
figure('Name','BER Sumada - comparativo'); hold on; grid on;
for k = 1:numel(data)
    SNRv = data(k).SNRvec;
    berv  = data(k).berSum;
    minpos = min(berv(berv>0));
    if isempty(minpos), minpos = 1e-6; end
    berv_safe = berv;
    berv_safe(berv_safe==0) = minpos/10;
    plot(SNRv, berv, ['-' markers{mod(k-1,numel(markers))+1}], 'Color', cols(k,:), ...
        'LineWidth', 1, 'MarkerSize',6, 'DisplayName', data(k).label);
    smoothBer = interpBER(SNRv, berv_safe, SNRfine);
    semilogy(SNRfine, smoothBer, 'Color', cols(k,:), 'LineWidth', 1.6);
end
set(gca,'YScale','log');
xlabel('SNR (dB)'); ylabel('BER sum'); title('BER_{com}+BER_{nav} vs SNR');
xlim([SNR_min SNR_max]); ylim([1e-6 1]);
legend('Location','southwest'); hold off;

%% ===== Función auxiliar local usando fit() =====
function smoothBer = smoothBERfit(SNRin, BERin, SNRfine)
    % Usa la función fit() de MATLAB para ajuste robusto con detección de ruptura
    
    SNRin = SNRin(:)';
    BERin = BERin(:)';
    
    % Filtrar datos válidos
    validIdx = ~isnan(BERin) & (BERin > 0);
    if sum(validIdx) < 3
        % Fallback a interpolación básica si no hay suficientes puntos
        smoothBer = basicInterpolation(SNRin, BERin, SNRfine);
        return;
    end
    
    SNR_valid = SNRin(validIdx);
    BER_valid = BERin(validIdx);
    
    % Convertir a escala logarítmica para el ajuste
    logBER = log10(BER_valid);
    
    try
        % Opción 1: Ajuste polinomial cúbico (suave y curvado hacia abajo)
        [fitresult, ~] = fit(SNR_valid', logBER', 'poly3', ...
            'Robust', 'Bisquare', 'Normalize', 'on');
        
        % Evaluar el ajuste
        logBER_fine = fitresult(SNRfine');
        smoothBer = 10.^logBER_fine';
        
    catch
        % Fallback a interpolación spline si fit falla
        warning('Fit polinomial falló, usando spline de respaldo');
        smoothBer = basicInterpolation(SNRin, BERin, SNRfine);
        return;
    end
    
    % Detección de ruptura de tendencia (versión simplificada)
    smoothBer = detectTrendBreakSimplified(SNRfine, smoothBer, SNR_valid, BER_valid);
end

%% Función simplificada para detección de ruptura de tendencia
function y_out = detectTrendBreakSimplified(x, y, x_orig, y_orig)
    % Detección simplificada de ruptura de tendencia
    
    y_out = y;
    
    if numel(y) < 5
        return;
    end
    
    % Calcular derivada numérica
    dy = diff(y) ./ diff(x);
    
    % Buscar donde la derivada se vuelve positiva o cero (ruptura)
    positive_slope_idx = find(dy >= -1e-8, 1); % Casi plano o positivo
    
    if ~isempty(positive_slope_idx)
        break_idx = positive_slope_idx + 1;
        
        % Verificación adicional: comparar con datos originales
        if break_idx < numel(x)
            % Si hay datos originales después del punto de ruptura, verificar
            x_break = x(break_idx);
            orig_after_break = x_orig(x_orig >= x_break);
            
            if ~isempty(orig_after_break)
                % Si hay datos originales después de la ruptura, no cortar
                return;
            end
            
            % Cortar la curva asignando NaN
            y_out(break_idx:end) = NaN;
            fprintf('Ruptura detectada en SNR = %.2f dB\n', x(break_idx));
        end
    end
    
    % Detección adicional: si la curva se aleja mucho de los datos originales
    for i = 1:numel(x)
        if i > 1 && ~isnan(y(i))
            % Buscar datos originales cercanos
            nearby_orig = find(abs(x_orig - x(i)) < 1.0); % Within 1 dB
            if ~isempty(nearby_orig)
                orig_vals = y_orig(nearby_orig);
                if y(i) > max(orig_vals) * 10 || y(i) < min(orig_vals) / 10
                    y_out(i:end) = NaN;
                    fprintf('Desviación detectada en SNR = %.2f dB\n', x(i));
                    break;
                end
            end
        end
    end
end

%% Función de interpolación básica (fallback)
function smoothBer = basicInterpolation(SNRin, BERin, SNRfine)
    % Interpolación básica de respaldo
    
    SNRin = SNRin(:)';
    BERin = BERin(:)';
    
    if numel(SNRin) < 2
        smoothBer = repmat(BERin(1), size(SNRfine));
        return;
    end
    
    % Filtrar datos válidos
    validIdx = ~isnan(BERin) & (BERin > 0);
    if sum(validIdx) < 2
        smoothBer = nan(size(SNRfine));
        return;
    end
    
    SNR_valid = SNRin(validIdx);
    BER_valid = BERin(validIdx);
    
    % Convertir a log10 y usar spline
    logBER = log10(BER_valid);
    logBER_fine = interp1(SNR_valid, logBER, SNRfine, 'spline', 'extrap');
    smoothBer = 10.^logBER_fine;
    
    % Limitar valores extremos
    minBER = min(BER_valid);
    maxBER = max(BER_valid);
    smoothBer(smoothBer < minBER/100) = minBER/100;
    smoothBer(smoothBer > maxBER*100) = maxBER*100;
end